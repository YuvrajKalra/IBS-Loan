package com.cg.ibs.loanmgmt.entities;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "Loans")
@SequenceGenerator(name = "appseq", initialValue = 1000, allocationSize = 1)
public class LoanMasterEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "appseq")
	@Column(name = "app_num", nullable = false)
	private BigInteger applicationNumber;
	@Column(name = "loan_account_num", unique = true)
	private BigInteger loanAccountNumber;
	@Column(name = "loan_amount", nullable = false)
	private BigDecimal loanAmount;
	@Column(name = "loan_tenure", nullable = false)
	private Integer loanTenure;
	@Column(name = "loan_type", nullable = false)
	private LoanType loanType;
	@Column(name = "loan_interest", nullable = false)
	private Float loanInterest;
	@Column(name = "balance", nullable = false)
	private BigDecimal balance;
	@Column(name = "applied_date", nullable = false)
	private LocalDate appliedDate;
	@Column(name = "total_num_of_emis", nullable = true)
	private Integer totalNumOfEmis;
	@Column(name = "num_of_emis_paid", nullable = true)
	private Integer numOfEmisPaid;
	@Column(name = "emi_amount", nullable = false)
	private BigDecimal emiAmount;
	@Enumerated(EnumType.STRING)
	@Column(name = "loan_status", nullable = false)
	private LoanStatus status;
	@Column(name = "next_emi_date")
	private LocalDate nextEmiDate;
	@Column(name = "loan_approved_date")
	private LocalDate approvedDate;
	@Column(name = "loan_closed_date")
	private LocalDate loanClosedDate;
	@Column(name = "preclosure_applied_date")
	private LocalDate preclosureAppliedDate;
	@Column(name = "preclosure_approved_date")
	private LocalDate preclosureApprovedDate;
	@Column(name = "preclosure_denied_date")
	private LocalDate preclosureDeniedDate;
	@Column(name = "loan_denied_date")
	private LocalDate loanDeniedDate;
	@ManyToOne
	@JoinColumn(name = "uci")
	private Customer customer;

	@ManyToOne
	private Account savings_Account;

	@ManyToOne
	@JoinColumn
	private Banker loan_Approver;

	@ManyToOne
	@JoinColumn
	private Banker pre_Closure_Approver;

	@Transient
	private String remarks;

	public LocalDate getPreclosureDeniedDate() {
		return preclosureDeniedDate;
	}

	public void setPreclosureDeniedDate(LocalDate preclosureDeniedDate) {
		this.preclosureDeniedDate = preclosureDeniedDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public LocalDate getLoanDeniedDate() {
		return loanDeniedDate;
	}

	public void setLoanDeniedDate(LocalDate loanDeniedDate) {
		this.loanDeniedDate = loanDeniedDate;
	}

	public Banker getLoan_Approver() {
		return loan_Approver;
	}

	public void setLoan_Approver(Banker loan_Approver) {
		this.loan_Approver = loan_Approver;
	}

	public BigInteger getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(BigInteger applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public BigInteger getLoanAccountNumber() {
		return loanAccountNumber;
	}

	public void setLoanAccountNumber(BigInteger loanAccountNumber) {
		this.loanAccountNumber = loanAccountNumber;
	}

	public BigDecimal getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}

	public Integer getLoanTenure() {
		return loanTenure;
	}

	public void setLoanTenure(Integer loanTenure) {
		this.loanTenure = loanTenure;
	}

	public LoanType getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}

	public Float getLoanInterest() {
		return loanInterest;
	}

	public void setLoanInterest(Float loanInterest) {
		this.loanInterest = loanInterest;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public LocalDate getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(LocalDate appliedDate) {
		this.appliedDate = appliedDate;
	}

	public Integer getTotalNumOfEmis() {
		return totalNumOfEmis;
	}

	public void setTotalNumOfEmis(Integer totalNumOfEmis) {
		this.totalNumOfEmis = totalNumOfEmis;
	}

	public Integer getNumOfEmisPaid() {
		return numOfEmisPaid;
	}

	public void setNumOfEmisPaid(Integer numOfEmisPaid) {
		this.numOfEmisPaid = numOfEmisPaid;
	}

	public BigDecimal getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(BigDecimal emiAmount) {
		this.emiAmount = emiAmount;
	}

	public LoanStatus getStatus() {
		return status;
	}

	public void setStatus(LoanStatus status) {
		this.status = status;
	}

	public LocalDate getNextEmiDate() {
		return nextEmiDate;
	}

	public void setNextEmiDate(LocalDate nextEmiDate) {
		this.nextEmiDate = nextEmiDate;
	}

	public LocalDate getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(LocalDate approvedDate) {
		this.approvedDate = approvedDate;
	}

	public LocalDate getLoanClosedDate() {
		return loanClosedDate;
	}

	public void setLoanClosedDate(LocalDate loanClosedDate) {
		this.loanClosedDate = loanClosedDate;
	}

	public LocalDate getPreclosureAppliedDate() {
		return preclosureAppliedDate;
	}

	public void setPreclosureAppliedDate(LocalDate preclosureAppliedDate) {
		this.preclosureAppliedDate = preclosureAppliedDate;
	}

	public LocalDate getPreclosureApprovedDate() {
		return preclosureApprovedDate;
	}

	public void setPreclosureApprovedDate(LocalDate preclosureApprovedDate) {
		this.preclosureApprovedDate = preclosureApprovedDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Account getSavings_Account() {
		return savings_Account;
	}

	public void setSavings_Account(Account savings_Account) {
		this.savings_Account = savings_Account;
	}

	public Banker getLoanApprover() {
		return loan_Approver;
	}

	public void setLoanApprover(Banker loanApprover) {
		this.loan_Approver = loanApprover;
	}

	public Banker getPre_Closure_Approver() {
		return pre_Closure_Approver;
	}

	public void setPre_Closure_Approver(Banker pre_Closure_Approver) {
		this.pre_Closure_Approver = pre_Closure_Approver;
	}

}
