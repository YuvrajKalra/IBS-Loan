package com.cg.ibs.loanmgmt.entities;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Loan_types")
public class LoanTypeEntity {

	@Id
	@Column(name = "type_Id", nullable = false)
	private Integer typeId;
	@Enumerated(EnumType.STRING)
	@Column(name = "loan_type", nullable = false)
	private LoanType loanType;
	@Column(name = "interest_rate", nullable = false)
	private Float interestRate;
	@Column(name = "maximum_limit", nullable = false)
	private BigDecimal maximumLimit;
	@Column(name = "minimum_limit", nullable = false)
	private BigDecimal minimumLimit;

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public LoanType getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}

	public Float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Float interestRate) {
		this.interestRate = interestRate;
	}

	public BigDecimal getMaximumLimit() {
		return maximumLimit;
	}

	public void setMaximumLimit(BigDecimal maximumLimit) {
		this.maximumLimit = maximumLimit;
	}

	public BigDecimal getMinimumLimit() {
		return minimumLimit;
	}

	public void setMinimumLimit(BigDecimal minimumLimit) {
		this.minimumLimit = minimumLimit;
	}

}
