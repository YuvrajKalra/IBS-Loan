package com.cg.ibs.loanmgmt.model;

import java.math.BigDecimal;

import com.cg.ibs.loanmgmt.entities.LoanType;

public class LoanTypeModel {
	private Integer typeId;
	private LoanType loanType;
	private Float interestRate;
	private BigDecimal maximumLimit;
	private BigDecimal minimumLimit;

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public LoanType getLoanType() {
		return loanType;
	}

	public void setLoanType(LoanType loanType) {
		this.loanType = loanType;
	}

	public Float getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Float interestRate) {
		this.interestRate = interestRate;
	}

	public BigDecimal getMaximumLimit() {
		return maximumLimit;
	}

	public void setMaximumLimit(BigDecimal maximumLimit) {
		this.maximumLimit = maximumLimit;
	}

	public BigDecimal getMinimumLimit() {
		return minimumLimit;
	}

	public void setMinimumLimit(BigDecimal minimumLimit) {
		this.minimumLimit = minimumLimit;
	}

}
