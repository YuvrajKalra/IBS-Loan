package com.cg.ibs.loanmgmt.entities;

public enum TransactionMode {
	ONLINE, CASH, CARD;
}
