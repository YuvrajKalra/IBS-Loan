package com.cg.ibs.loanmgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.ibs.loanmgmt.entities.Banker;
import java.lang.String;
import java.util.List;

public interface BankerDao extends JpaRepository<Banker, Integer>{
	Banker findByUserId(String userid);
}

