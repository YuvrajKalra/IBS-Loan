package com.cg.ibs.loanmgmt.service;

import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.dao.BankerDao;
import com.cg.ibs.loanmgmt.dao.LoanMasterDao;
import com.cg.ibs.loanmgmt.dao.VerificationDetailsDao;
import com.cg.ibs.loanmgmt.entities.Banker;
import com.cg.ibs.loanmgmt.entities.LoanMasterEntity;
import com.cg.ibs.loanmgmt.entities.LoanStatus;
import com.cg.ibs.loanmgmt.entities.VerificationDetailsEntity;
import com.cg.ibs.loanmgmt.model.BankerModel;
import com.cg.ibs.loanmgmt.model.LoanMasterModel;

@Service("verifyLoanService")
public class VerifyLoanServiceImpl implements VerifyLoanService {
	@Autowired
	LoanMasterDao loanMasterDao;
	@Autowired
	ApplyLoanService applyLoanService;
	@Autowired
	BankerDao bankerDao;
	@Autowired
	VerificationDetailsDao verificationDetailsDao;

	@Override
	public List<LoanMasterModel> findLoansToBeVerified(String bankerUserId) {
		Banker banker = bankerDao.findByUserId(bankerUserId);
		List<LoanMasterEntity> pendingLoans = loanMasterDao.findLoansToBeVerified(banker);
		for (LoanMasterEntity loanMasterEntity : pendingLoans) {
			System.out.println("insideloopp");
			System.out.println(loanMasterEntity.getApplicationNumber());
		}
		List<LoanMasterModel> pendingLoansModel = new ArrayList<>();
		if (pendingLoans.isEmpty()) {
			pendingLoansModel = null;
		} else {
			for (LoanMasterEntity loanMasterEntity : pendingLoans) {
				LoanMasterModel loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
				pendingLoansModel.add(loanMasterModel);
			}
		}
		return pendingLoansModel;
	}

	@Override
	public LoanMasterModel findLoanToBeVerified(BankerModel banker) {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findLoansByAppNum(banker.getVerifyApplicationNumber());
		return applyLoanService.valueOf(loanMasterEntity);
	}

	private BigInteger generateLoanNo(LoanMasterEntity loanMasterEntity) {
		StringBuilder sb = new StringBuilder();
		sb.append(LocalDate.now().getYear()).append(LocalDate.now().getMonthValue())
				.append(loanMasterEntity.getApplicationNumber());
		BigInteger loanNumber = new BigInteger(sb.toString());
		return loanNumber;
	}
	
	@Override
	public LoanMasterModel verifyLoan(LoanMasterModel loanMasterModel, Integer choice) {
		LoanMasterEntity loanMasterEntity = loanMasterDao.findLoansByAppNum(loanMasterModel.getApplicationNumber());
		System.out.println(loanMasterEntity.getApplicationNumber());
		VerificationDetailsEntity detail = new VerificationDetailsEntity();
		switch (choice) {
		case 1:
			loanMasterEntity.setApprovedDate(LocalDate.now());
			loanMasterEntity.setBalance(loanMasterEntity.getLoanAmount());
			loanMasterEntity.setLoanAccountNumber(generateLoanNo(loanMasterEntity));
			loanMasterEntity.setTotalNumOfEmis(loanMasterEntity.getLoanTenure());
			loanMasterEntity.setNextEmiDate(loanMasterEntity.getAppliedDate().plusMonths(1));
			loanMasterEntity.setNumOfEmisPaid(0);
			loanMasterEntity.setStatus(LoanStatus.APPROVED);
			loanMasterEntity.getSavings_Account().setBalance(
					loanMasterEntity.getSavings_Account().getBalance().add(loanMasterEntity.getLoanAmount()));

			detail.setApplicationNumber(loanMasterEntity.getApplicationNumber());
			detail.setRemarks(loanMasterModel.getRemarks());
			detail.setQueryStatus(LoanStatus.APPROVED);
			loanMasterEntity = loanMasterDao.save(loanMasterEntity);
			detail = verificationDetailsDao.save(detail);
			break;

		case 2:
			loanMasterEntity.setStatus(LoanStatus.DENIED);
			loanMasterEntity.setLoanDeniedDate(LocalDate.now());
			detail.setApplicationNumber(loanMasterEntity.getApplicationNumber());
			detail.setRemarks(loanMasterModel.getRemarks());
			detail.setQueryStatus(LoanStatus.DENIED);
			loanMasterEntity = loanMasterDao.save(loanMasterEntity);
			detail = verificationDetailsDao.save(detail);
			break;
		}
		loanMasterModel = applyLoanService.valueOf(loanMasterEntity);
		loanMasterModel.setRemarks(detail.getRemarks());
		System.out.println(loanMasterModel.getLoanAccountNumber());
		return loanMasterModel;
	}

}
