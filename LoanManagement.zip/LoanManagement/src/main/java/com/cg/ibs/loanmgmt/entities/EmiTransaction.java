package com.cg.ibs.loanmgmt.entities;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "Emi_Transactions")
@SequenceGenerator(name = "Emi_tran_seq", initialValue = 50, allocationSize = 1)
public class EmiTransaction {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Emi_tran_seq")
	@Column(name = "TRANS_ID", nullable = false, length = 10)
	private Integer transactionId;

	@Column(name = "TRANS_TYPE", nullable = false, length = 20)
	@Enumerated(EnumType.STRING)
	private TransactionType transactionType;

	@Column(name = "TRANS_DATE_TIME", nullable = false, length = 20)
	private LocalDateTime transactionDate;

	@Column(name = "AMOUNT", nullable = false, length = 10)
	private BigDecimal transactionAmount;

	@Column(name = "TRANS_MODE", nullable = false, length = 20)
	@Enumerated(EnumType.STRING)
	private TransactionMode transactionMode;

	@Column(name = "TRANS_DESC", nullable = false, length = 40)
	private String transactionDescription;

	@Column(name = "emi_number", nullable = true, length = 4)
	private Integer emiNumber;
	
	@Column(name = "REFERENCE_ID", length = 60)
	private String referenceId;

	

	@ManyToOne
	@JoinColumn(name = "loan_account_number")
	private LoanMasterEntity loanMasterAccountNumber;

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}
	
	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public TransactionType getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(TransactionType transactionType) {
		this.transactionType = transactionType;
	}

	public LocalDateTime getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDateTime transactionDate) {
		this.transactionDate = transactionDate;
	}

	public BigDecimal getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(BigDecimal transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public TransactionMode getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(TransactionMode transactionMode) {
		this.transactionMode = transactionMode;
	}

	public String getTransactionDescription() {
		return transactionDescription;
	}

	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}

	public Integer getEmiNumber() {
		return emiNumber;
	}

	public void setEmiNumber(Integer emiNumber) {
		this.emiNumber = emiNumber;
	}

	public LoanMasterEntity getLoanMasterAccountNumber() {
		return loanMasterAccountNumber;
	}

	public void setLoanMasterAccountNumber(LoanMasterEntity loanMasterAccountNumber) {
		this.loanMasterAccountNumber = loanMasterAccountNumber;
	}

}
